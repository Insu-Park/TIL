$(document).ready(function (){
	$('#loginBtn').click(function(){
		var id=$('#id').val();
		var pw=$('#pw').val();
		alert(id+":"+pw);
		$.post("/main",
		{
			
		},
		function(data, status){
			alert("Data: " + data + "님 login ok\nStatus: " + status);
		});
	});
});

function onClick() {
  alert('AI 기술 사이트로 이동하시겠습니까?');
}

document.getElementById('banner2').addEventListener('click', onClick); // 이벤트 연결
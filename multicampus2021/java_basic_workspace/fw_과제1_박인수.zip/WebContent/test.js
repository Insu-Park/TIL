$(document).ready(function (){
	$('#loginBtn').click(function(){
		var id=$('#id').val();
		var pw=$('#pw').val();
		alert(id+":"+pw);

	});
});

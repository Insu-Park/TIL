
AI.onclick = function () {
	alert("AI 기술 사이트로 이동하시겠습니까?");	
};

